<footer class="footer pt-3  ">
    <div class="container-fluid">
        <div class="row align-items-center justify-content-lg-between">
            
            
        </div>
    </div>
</footer>
<?php /**PATH C:\laragon\www\tchop\resources\views/layouts/footers/auth/footer.blade.php ENDPATH**/ ?>