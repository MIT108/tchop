<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ServiceAccountController extends Controller
{
    //
}
